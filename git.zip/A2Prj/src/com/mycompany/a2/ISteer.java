package com.mycompany.a2;

public interface ISteer {
	public void steerLeft();
	public void steerRight();
}
