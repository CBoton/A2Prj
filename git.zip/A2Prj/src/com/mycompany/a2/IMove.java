package com.mycompany.a2;

public interface IMove {
	public void move();
}
